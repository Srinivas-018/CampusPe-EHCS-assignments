local http = require "http"
local shortport = require "shortport"
local stdnse = require "stdnse"

description = [[
  Simple NSE script to fetch the HTTP Server header, 
  status code, and page title from the root directory.
]]

author = "MCA Student"
categories = {"discovery", "safe"}

portrule = shortport.port_or_service({80, 8080}, "http")

action = function(host, port)
  -- Perform the GET request
  local response = http.get(host, port, "/")
  
  -- Check if the response exists and has a status
  if not (response and response.status) then
    return "Error: Could not retrieve page (Connection refused or timeout)."
  end

  local results = {}

  -- 1. Display Status Code
  table.insert(results, string.format("HTTP Status: %s", response.status))
  
  -- 2. Extract Server Header safely
  if response.header and response.header.server then
    table.insert(results, string.format("Server Header: %s", response.header.server))
  else
    table.insert(results, "Server Header: Not disclosed")
  end

  -- 3. Extract Page Title safely
  if response.body then
    local title = string.match(response.body, "<title>(.-)</title>")
    if title then
      -- Clean up any newlines in the title
      title = string.gsub(title, "[\n\r]", "")
      table.insert(results, string.format("Page Title: %s", title))
    else
      table.insert(results, "Page Title: No <title> tag found")
    end
  else
    table.insert(results, "Page Title: Empty response body")
  end

  return stdnse.format_output(true, results)
end