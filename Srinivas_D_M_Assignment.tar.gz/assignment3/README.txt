Student Information
* Name: Srinivas DM.
* USN: 1BI24MC145.
* Course: Cybersecurity and Ethical-Hacking Intern.
* Assignment: Assignment 3. 

Assignment Overview
This assignment covers the practical application of Linux administration, Python security scripting, C programming memory management, and network scanning over a 2-week training period.

Technical Details & Notes
Section 1: Linux & Bash
* Task 1.1: All 10 required Linux commands for file management, searching, and system discovery are included in section1_commands.txt.
* Task 1.2: port_report.sh accepts a target IP and scans ports 21, 22, 80, 443, and 3306, saving the result to a timestamped file.
Section 2: Python Security
* Password Checker: Implements Regex to score passwords based on complexity requirements (Length 8+, upper, lower, numbers, special).
* Network Scanner: Uses the socket library to report OPEN/CLOSED status and measures total scan duration.
Section 4: C Programming
* Pointers: pointer_basics.c manages the update of the port variable from 80 to 443 using pointer dereferencing.
* Buffer Overflow: buffer_test.c demonstrates the danger of strcpy(). Findings regarding segmentation faults and fixes (using strncpy) are included in the code comments.
Section 5: Nmap & NSE
* Documented scans were performed exclusively on authorized targets: scanme.nmap.org.
* The http-server-info.nse script extracts the Server header, status code, and page title.

Submission Checklist
*  Tested on Kali Linux/Ubuntu 
*  Folder structure matches requirements 
*  All code runs without errors 
*  README includes all student details 
*  Academic integrity followed (Individual work) 

