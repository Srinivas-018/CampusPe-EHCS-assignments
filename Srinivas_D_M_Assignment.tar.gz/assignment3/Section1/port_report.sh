#!/bin/bash

# 1. Check if target IP is provided
if [ -z "$1" ]; then
    echo "Usage: $0 <target_ip>"
    exit 1
fi

TARGET=$1
DATE=$(date +%Y-%m-%d)
OUTPUT_FILE="scan_${TARGET}_${DATE}.txt"
PORTS=(21 22 80 443 3306)
OPEN_COUNT=0

echo "Starting scan on $TARGET..."
echo "Scan Results for $TARGET - $DATE" > "$OUTPUT_FILE"
echo "-----------------------------------" >> "$OUTPUT_FILE"

# 2. Scan common ports
for PORT in "${PORTS[@]}"; do
    # nc -z waits for a connection, -w 1 sets a 1-second timeout
    if nc -z -w 1 "$TARGET" "$PORT" 2>/dev/null; then
        echo "Port $PORT: OPEN" >> "$OUTPUT_FILE"
        ((OPEN_COUNT++))
    else
        echo "Port $PORT: CLOSED" >> "$OUTPUT_FILE"
    fi
done

# 3. Display summary
echo "Scan complete. Results saved to $OUTPUT_FILE"
echo "Summary: Total open ports found: $OPEN_COUNT"