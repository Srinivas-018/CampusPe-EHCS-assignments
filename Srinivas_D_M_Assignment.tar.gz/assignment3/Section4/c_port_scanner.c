#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

// Function to scan a single port
void scan_port(const char* ip, int port) {
    int sock;
    struct sockaddr_in server;

    // 1. Create a TCP socket
    // AF_INET = IPv4, SOCK_STREAM = TCP, 0 = Protocol
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        printf("Could not create socket\n");
        return;
    }

    // 2. Define the target server details
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr(ip);
    server.sin_port = htons(port); // Host to Network Short (endianness)

    // 3. Attempt to connect
    // If connect returns 0, the port is OPEN
    if (connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
        printf("Port %d: CLOSED\n", port);
    } else {
        printf("Port %d: OPEN\n", port);
    }

    // 4. Close the socket
    close(sock);
}

int main() {
    const char* target_ip = "127.0.0.1";
    int ports_to_scan[] = {22, 80, 443, 3306};
    int num_ports = sizeof(ports_to_scan) / sizeof(ports_to_scan[0]);

    printf("Scanning localhost (%s)...\n", target_ip);
    printf("------------------------------\n");

    for (int i = 0; i < num_ports; i++) {
        scan_port(target_ip, ports_to_scan[i]);
    }

    return 0;
}