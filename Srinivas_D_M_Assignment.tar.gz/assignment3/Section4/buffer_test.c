#include <stdio.h>
#include <string.h>

int main() {
    // 1. Create a buffer of size 16
    char buffer[16];
    char user_input[64]; // Larger container to hold the raw input before copying

    printf("Enter some text: ");
    
    // Using scanf to grab a long string (including spaces)
    scanf("%s", user_input);

    printf("\n--- Before Copying ---\n");
    printf("Buffer address: %p\n", (void*)&buffer);
    
    // 2 & 3. Use strcpy() (unsafe) to copy input
    // This is where the overflow happens because strcpy does not check bounds
    strcpy(buffer, user_input);

    printf("\n--- After Copying ---\n");
    printf("Buffer content: %s\n", buffer);
    printf("Copy successful!\n");

    return 0;
}

/* --- ANSWERS TO LAB QUESTIONS ---

  1. What happens with long input?
     When you provide 30+ characters, the data fills the 16 bytes allocated for 
     'buffer' and then continues writing into the adjacent memory. This usually 
     results in a "Segmentation Fault" (crash) because you've overwritten the 
     function's return address or other critical stack data.

  2. Why is this dangerous?
     It is dangerous because an attacker can intentionally craft a "long input" 
     containing malicious machine code (shellcode). By overwriting the return 
     address, they can force the CPU to execute their code instead of the 
     original program, leading to unauthorized access or remote code execution.

  3. How would you fix it?
     Replace the unsafe 'strcpy()' with 'strncpy()', which allows you to 
     specify the maximum number of bytes to copy:
     
     strncpy(buffer, user_input, sizeof(buffer) - 1);
     buffer[sizeof(buffer) - 1] = '\0'; // Ensure null termination
*/