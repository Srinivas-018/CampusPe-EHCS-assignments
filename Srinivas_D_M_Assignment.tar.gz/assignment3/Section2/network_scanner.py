import socket
import sys
import time
from datetime import datetime

def scan_ports(target_ip, ports):
    results = []
    print(f"Scanning target: {target_ip}")
    print("-" * 40)
    
    start_time = time.time()
    
    for port in ports:
        # Create a TCP socket
        # AF_INET = IPv4, SOCK_STREAM = TCP
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.5)  # Half-second timeout for speed
        
        result = s.connect_ex((target_ip, port))
        
        if result == 0:
            status = "OPEN"
        else:
            status = "CLOSED"
            
        res_string = f"Port {port}: {status}"
        print(res_string)
        results.append(res_string)
        s.close()
        
    end_time = time.time()
    duration = round(end_time - start_time, 2)
    
    return results, duration

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 network_scanner.py <IP> <port1,port2,port3...>")
        sys.exit(1)

    target = sys.argv[1]
    # Convert comma-separated string to list of integers
    try:
        port_list = [int(p) for p in sys.argv[2].split(",")]
    except ValueError:
        print("Error: Ports must be a comma-separated list of numbers.")
        sys.exit(1)

    results, duration = scan_ports(target, port_list)

    # Save to file
    with open("scan_results.txt", "w") as f:
        f.write(f"Scan Report for {target}\n")
        f.write(f"Date: {datetime.now()}\n")
        f.write("-" * 30 + "\n")
        for line in results:
            f.write(line + "\n")
        f.write("-" * 30 + "\n")
        f.write(f"Scan Duration: {duration} seconds\n")

    print("-" * 40)
    print(f"Scan finished in {duration} seconds.")
    print("Results saved to scan_results.txt")

if __name__ == "__main__":
    main()