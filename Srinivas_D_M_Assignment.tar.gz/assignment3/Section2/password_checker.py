import re

def check_password_strength(password):
    score = 0
    recommendations = []

    # 1. Check Length
    if len(password) >= 8:
        score += 1
    else:
        recommendations.append("- Make it at least 8 characters long")

    # 2. Check Uppercase
    if re.search(r'[A-Z]', password):
        score += 1
    else:
        recommendations.append("- Add an uppercase letter (A-Z)")

    # 3. Check Lowercase
    if re.search(r'[a-z]', password):
        score += 1
    else:
        recommendations.append("- Add a lowercase letter (a-z)")

    # 4. Check Numbers
    if re.search(r'[0-9]', password):
        score += 1
    else:
        recommendations.append("- Add at least one number (0-9)")

    # 5. Check Special Characters
    if re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        score += 1
    else:
        recommendations.append("- Add a special character (e.g., !, @, #, $)")

    # Determine Rating
    if score <= 2:
        rating = "Weak"
    elif score <= 4:
        rating = "Medium"
    else:
        rating = "Strong"

    return score, rating, recommendations

def main():
    print("--- Password Strength Checker ---")
    user_pass = input("Enter password to check: ")
    
    score, rating, recs = check_password_strength(user_pass)

    print(f"\nResults:")
    print(f"Score: {score}/5")
    print(f"Rating: {rating}")

    if recs:
        print("\nRecommendations to improve:")
        for r in recs:
            print(r)
    else:
        print("\nGreat job! Your password meets all security criteria.")

if __name__ == "__main__":
    main()