import subprocess
import re
import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

def get_arp_table():
    """
    Executes the 'arp -a' command and returns the raw output.
    """
    try:
        # 'arp -a' is a universal command across Windows, Linux, and macOS
        output = subprocess.check_output(['arp', '-a']).decode('utf-8', errors='ignore')
        return output
    except Exception as e:
        return f"Error retrieving ARP table: {e}"

def parse_arp(raw_output):
    """
    Parses the ARP output using regex to find IP and MAC addresses.
    """
    # Regex breakdown:
    # IP: matches 1-3 digits separated by dots
    # MAC: matches 6 pairs of hex digits separated by colons, dashes, or dots
    ip_pattern = r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
    mac_pattern = r'([0-9a-fA-F]{2}[:-][0-9a-fA-F]{2}[:-][0-9a-fA-F]{2}[:-][0-9a-fA-F]{2}[:-][0-9a-fA-F]{2}[:-][0-9a-fA-F]{2})'
    
    lines = raw_output.splitlines()
    mappings = []

    for line in lines:
        ip_match = re.search(ip_pattern, line)
        mac_match = re.search(mac_pattern, line)
        
        if ip_match and mac_match:
            mappings.append({
                'ip': ip_match.group(1),
                'mac': mac_match.group(1).replace('-', ':').lower()
            })
            
    return mappings

def save_to_file(data, count):
    filename = "arp_results.txt"
    with open(filename, "w") as f:
        f.write(f"Total ARP Entries Found: {count}\n")
        f.write("-" * 40 + "\n")
        f.write(f"{'IP Address':<20} | {'MAC Address'}\n")
        for entry in data:
            f.write(f"{entry['ip']:<20} | {entry['mac']}\n")
    return os.path.abspath(filename)


class ArpScannerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Local ARP Table Scanner")
        self.geometry("720x520")
        self.minsize(620, 420)

        self.mappings = []
        self.total = 0

        self._build_ui()

    def _build_ui(self):
        top = tk.Frame(self, padx=12, pady=10)
        top.pack(fill="x")

        tk.Label(top, text="Local ARP Table Scanner", font=("Segoe UI", 14, "bold")).pack(anchor="w")
        tk.Label(top, text="Click Scan ARP Table to load IP/MAC entries from your local ARP cache.",
                 fg="#555").pack(anchor="w", pady=(2, 8))

        btn_row = tk.Frame(top)
        btn_row.pack(fill="x")

        self.scan_btn = tk.Button(btn_row, text="Scan ARP Table", command=self.scan_arp)
        self.scan_btn.pack(side="left")

        tk.Button(btn_row, text="Save Results", command=self.save_results).pack(side="left", padx=8)
        tk.Button(btn_row, text="Clear", command=self.clear_results).pack(side="left")

        self.status_var = tk.StringVar(value="Ready")
        tk.Label(top, textvariable=self.status_var, fg="#0a58ca").pack(anchor="w", pady=(8, 0))

        table_frame = tk.Frame(self, padx=12, pady=8)
        table_frame.pack(fill="both", expand=True)

        self.tree = ttk.Treeview(table_frame, columns=("ip", "mac"), show="headings")
        self.tree.heading("ip", text="IP Address")
        self.tree.heading("mac", text="MAC Address")
        self.tree.column("ip", width=260, anchor="w")
        self.tree.column("mac", width=280, anchor="w")

        yscroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=yscroll.set)

        self.tree.pack(side="left", fill="both", expand=True)
        yscroll.pack(side="right", fill="y")

        bottom = tk.Frame(self, padx=12, pady=8)
        bottom.pack(fill="x")
        self.total_var = tk.StringVar(value="Total Entries Found: 0")
        tk.Label(bottom, textvariable=self.total_var, font=("Segoe UI", 10, "bold")).pack(anchor="w")

    def scan_arp(self):
        self.status_var.set("Scanning ARP table...")
        self.update_idletasks()

        raw_data = get_arp_table()
        if raw_data.startswith("Error retrieving ARP table:"):
            self.status_var.set("Scan failed")
            messagebox.showerror("ARP Scan Error", raw_data)
            return

        self.mappings = parse_arp(raw_data)
        self.total = len(self.mappings)
        self._refresh_table()

        self.total_var.set(f"Total Entries Found: {self.total}")
        self.status_var.set("Scan complete")

    def _refresh_table(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        for entry in self.mappings:
            self.tree.insert("", "end", values=(entry["ip"], entry["mac"]))

    def clear_results(self):
        self.mappings = []
        self.total = 0
        self._refresh_table()
        self.total_var.set("Total Entries Found: 0")
        self.status_var.set("Cleared")

    def save_results(self):
        if not self.mappings:
            messagebox.showinfo("No Data", "No ARP entries to save. Please scan first.")
            return

        path = filedialog.asksaveasfilename(
            title="Save ARP Results",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            initialfile="arp_results.txt",
        )
        if not path:
            return

        with open(path, "w") as f:
            f.write(f"Total ARP Entries Found: {self.total}\n")
            f.write("-" * 40 + "\n")
            f.write(f"{'IP Address':<20} | {'MAC Address'}\n")
            for entry in self.mappings:
                f.write(f"{entry['ip']:<20} | {entry['mac']}\n")

        self.status_var.set(f"Saved: {path}")
        messagebox.showinfo("Saved", f"Results saved to:\n{path}")

def main():
    app = ArpScannerApp()
    app.mainloop()

if __name__ == "__main__":
    main()