import subprocess
import sys
import threading
import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
from datetime import datetime


# ── Core scanning logic ───────────────────────────────────────────────────────

def check_nmap():
    """Returns True if nmap is installed and accessible in the system PATH."""
    try:
        subprocess.run(['nmap', '--version'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return True
    except FileNotFoundError:
        return False


def build_command(target, scan_type, custom_ports=None):
    """Builds the nmap command list from user selections."""
    command = ['nmap']
    if scan_type == '1':
        command.append('-sn')
    elif scan_type == '2':
        command.extend(['-p', '1-1000'])
    elif scan_type == '3':
        if custom_ports:
            command.extend(['-p', custom_ports])
    elif scan_type == '4':
        command.append('-sV')
    elif scan_type == '5':
        command.append('-O')
    command.append(target)
    return command


def run_nmap_scan(target, scan_type, custom_ports=None):
    """Executes the nmap command and returns (command_str, output)."""
    command = build_command(target, scan_type, custom_ports)
    cmd_str = ' '.join(command)
    try:
        result = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=300,
        )
        output = result.stdout if result.returncode == 0 else f"Error:\n{result.stderr}"
    except subprocess.TimeoutExpired:
        output = "Error: The scan timed out (5-minute limit reached)."
    except Exception as exc:
        output = f"Unexpected error: {exc}"
    return cmd_str, output


# ── Theme / colour constants ──────────────────────────────────────────────────

BG        = "#1e1e2e"
PANEL     = "#2a2a3e"
ACCENT    = "#7c3aed"
ACCENT_LT = "#a78bfa"
FG        = "#e2e8f0"
FG_DIM    = "#94a3b8"
GREEN     = "#22c55e"
RED       = "#ef4444"
YELLOW    = "#eab308"
MONO      = ("Courier New", 10)
SANS      = ("Segoe UI", 10)

SCAN_OPTIONS = [
    ("1", "Host Discovery           (-sn)"),
    ("2", "Port Scan 1-1000   (-p 1-1000)"),
    ("3", "Custom Port Range (-p <ports>)"),
    ("4", "Service Version          (-sV)"),
    ("5", "OS Detection              (-O)"),
]


# ── GUI Application ───────────────────────────────────────────────────────────

class NmapScannerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Nmap Scanner")
        self.geometry("900x660")
        self.minsize(720, 500)
        self.configure(bg=BG)
        self._scan_thread = None
        self._build_ui()
        self._check_nmap_on_start()

    # ── UI construction ───────────────────────────────────────────────────────

    def _build_ui(self):
        # Header bar
        header = tk.Frame(self, bg=ACCENT, padx=16, pady=10)
        header.pack(fill="x")
        tk.Label(header, text="Nmap Scanner", font=("Segoe UI", 14, "bold"),
                 bg=ACCENT, fg="white").pack(side="left")
        self._nmap_badge = tk.Label(header, text="checking nmap…",
                                    font=("Segoe UI", 9), bg=ACCENT, fg="white")
        self._nmap_badge.pack(side="right", padx=6)

        # Two-column main area
        main = tk.Frame(self, bg=BG)
        main.pack(fill="both", expand=True, padx=14, pady=10)

        left = tk.Frame(main, bg=PANEL, padx=14, pady=14)
        left.pack(side="left", fill="y", padx=(0, 10))
        left.pack_propagate(False)
        left.configure(width=270)

        right = tk.Frame(main, bg=BG)
        right.pack(side="left", fill="both", expand=True)

        self._build_left_panel(left)
        self._build_right_panel(right)

        # Status bar
        self._status_var = tk.StringVar(value="Ready.")
        self._status_bar = tk.Label(self, textvariable=self._status_var,
                                    bg=PANEL, fg=FG_DIM,
                                    font=("Segoe UI", 9), anchor="w", padx=10, pady=5)
        self._status_bar.pack(fill="x", side="bottom")

    def _build_left_panel(self, parent):
        def section_label(text):
            tk.Label(parent, text=text, font=("Segoe UI", 9, "bold"),
                     bg=PANEL, fg=ACCENT_LT).pack(anchor="w", pady=(12, 2))

        # ── Target input ──
        section_label("TARGET")
        self._target_var = tk.StringVar()
        tk.Entry(parent, textvariable=self._target_var,
                 bg="#12121e", fg=FG, insertbackground=FG,
                 relief="flat", font=MONO, bd=6).pack(fill="x", ipady=4)
        tk.Label(parent, text="e.g.  192.168.1.1  or  192.168.1.0/24",
                 bg=PANEL, fg=FG_DIM, font=("Segoe UI", 8)).pack(anchor="w")

        # ── Scan type radio buttons ──
        section_label("SCAN TYPE")
        self._scan_var = tk.StringVar(value="1")
        for value, label in SCAN_OPTIONS:
            tk.Radiobutton(
                parent, text=label, variable=self._scan_var, value=value,
                bg=PANEL, fg=FG, selectcolor=ACCENT,
                activebackground=PANEL, activeforeground=FG,
                font=("Courier New", 9),
                command=self._on_scan_type_change,
            ).pack(anchor="w")

        # ── Custom ports (only active when option 3 is selected) ──
        ports_frame = tk.Frame(parent, bg=PANEL)
        ports_frame.pack(fill="x", pady=(6, 0))
        tk.Label(ports_frame, text="Custom ports:", bg=PANEL,
                 fg=FG_DIM, font=SANS).pack(anchor="w")
        self._ports_var = tk.StringVar()
        self._ports_entry = tk.Entry(ports_frame, textvariable=self._ports_var,
                                     bg="#12121e", fg=FG, insertbackground=FG,
                                     relief="flat", font=MONO, bd=6, state="disabled")
        self._ports_entry.pack(fill="x", ipady=3)
        tk.Label(ports_frame, text="e.g.  80,443  or  1-65535",
                 bg=PANEL, fg=FG_DIM, font=("Segoe UI", 8)).pack(anchor="w")

        # ── Action buttons ──
        tk.Frame(parent, bg=PANEL, height=12).pack()
        self._run_btn = tk.Button(
            parent, text="Run Scan",
            bg=ACCENT, fg="white", font=("Segoe UI", 10, "bold"),
            relief="flat", activebackground=ACCENT_LT, activeforeground="white",
            cursor="hand2", command=self._start_scan, pady=8,
        )
        self._run_btn.pack(fill="x")

        tk.Frame(parent, bg=PANEL, height=6).pack()
        tk.Button(parent, text="Clear Results", bg=PANEL, fg=FG_DIM,
                  font=("Segoe UI", 9), relief="flat", activebackground=BG,
                  activeforeground=FG, cursor="hand2",
                  command=self._clear_results).pack(fill="x")

        tk.Frame(parent, bg=PANEL, height=6).pack()
        tk.Button(parent, text="Save Results", bg=PANEL, fg=FG_DIM,
                  font=("Segoe UI", 9), relief="flat", activebackground=BG,
                  activeforeground=FG, cursor="hand2",
                  command=self._save_results).pack(fill="x")

    def _build_right_panel(self, parent):
        # Live command preview
        self._cmd_var = tk.StringVar(value="Command: —")
        tk.Label(parent, textvariable=self._cmd_var, bg=BG, fg=ACCENT_LT,
                 font=("Courier New", 9), anchor="w").pack(fill="x", pady=(0, 4))

        # Scrollable results area
        self._output = scrolledtext.ScrolledText(
            parent, bg="#0d0d1a", fg=FG, insertbackground=FG,
            font=MONO, relief="flat", wrap="word", state="disabled",
            padx=10, pady=10,
        )
        self._output.pack(fill="both", expand=True)

        # Colour tags for syntax highlighting
        self._output.tag_config("header",  foreground=ACCENT_LT, font=("Courier New", 10, "bold"))
        self._output.tag_config("open",    foreground=GREEN)
        self._output.tag_config("closed",  foreground=RED)
        self._output.tag_config("info",    foreground=YELLOW)
        self._output.tag_config("cmd",     foreground=FG_DIM, font=("Courier New", 9, "italic"))
        self._output.tag_config("divider", foreground=ACCENT)

    # ── Event handlers ────────────────────────────────────────────────────────

    def _on_scan_type_change(self):
        """Enable/disable the custom ports field based on scan type selection."""
        if self._scan_var.get() == '3':
            self._ports_entry.config(state="normal")
        else:
            self._ports_entry.config(state="disabled")
        self._update_cmd_preview()

    def _update_cmd_preview(self, *_):
        """Refresh the live command label as the user changes inputs."""
        target = self._target_var.get().strip() or "<target>"
        ports  = self._ports_var.get().strip() or None
        cmd    = build_command(target, self._scan_var.get(), ports)
        self._cmd_var.set("Command:  " + ' '.join(cmd))

    def _start_scan(self):
        """Validate inputs then launch the scan in a background thread."""
        target = self._target_var.get().strip()
        if not target:
            messagebox.showwarning("No Target", "Please enter a target IP or network range.")
            return
        if self._scan_var.get() == '3' and not self._ports_var.get().strip():
            messagebox.showwarning("No Ports", "Please enter a port range for the custom scan.")
            return
        if self._scan_thread and self._scan_thread.is_alive():
            messagebox.showinfo("Busy", "A scan is already running. Please wait.")
            return

        self._run_btn.config(state="disabled", text="Scanning…")
        self._set_status("Scanning — please wait…", YELLOW)
        self._clear_results()

        self._scan_thread = threading.Thread(
            target=self._scan_worker,
            args=(target, self._scan_var.get(), self._ports_var.get().strip() or None),
            daemon=True,
        )
        self._scan_thread.start()

    def _scan_worker(self, target, scan_type, custom_ports):
        """Runs in a background thread; posts results back to the main thread."""
        cmd_str, output = run_nmap_scan(target, scan_type, custom_ports)
        self.after(0, self._display_results, cmd_str, output)

    def _display_results(self, cmd_str, output):
        """Renders scan output into the results widget with colour highlighting."""
        ts = datetime.now().strftime("%Y-%m-%d  %H:%M:%S")

        self._output.config(state="normal")
        self._output.delete("1.0", "end")

        divider = "─" * 68
        self._append(divider + "\n", "divider")
        self._append(f"  Completed : {ts}\n", "info")
        self._append(f"  Command   : {cmd_str}\n", "cmd")
        self._append(divider + "\n\n", "divider")

        for line in output.splitlines():
            ll = line.lower()
            if line.startswith("Nmap scan report") or line.startswith("Starting Nmap"):
                self._append(line + "\n", "header")
            elif "open" in ll and ("tcp" in ll or "udp" in ll):
                self._append(line + "\n", "open")
            elif "closed" in ll or "filtered" in ll:
                self._append(line + "\n", "closed")
            elif line.startswith("OS") or "service" in ll or line.startswith("Host is"):
                self._append(line + "\n", "info")
            else:
                self._append(line + "\n")

        self._output.config(state="disabled")
        self._output.see("end")

        is_err = output.lower().startswith("error") or output.lower().startswith("unexpected")
        self._set_status("Scan finished." if not is_err else "Scan finished with errors.",
                         FG_DIM if not is_err else RED)
        self._run_btn.config(state="normal", text="Run Scan")

    def _append(self, text, tag=None):
        if tag:
            self._output.insert("end", text, tag)
        else:
            self._output.insert("end", text)

    def _clear_results(self):
        self._output.config(state="normal")
        self._output.delete("1.0", "end")
        self._output.config(state="disabled")
        self._set_status("Ready.", FG_DIM)

    def _save_results(self):
        content = self._output.get("1.0", "end").strip()
        if not content:
            messagebox.showinfo("Nothing to Save", "Run a scan first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            initialfile="nmap_report.txt",
        )
        if path:
            with open(path, "w") as f:
                f.write(content)
            self._set_status(f"Saved → {path}", GREEN)

    def _set_status(self, text, colour=FG_DIM):
        self._status_var.set(text)
        self._status_bar.config(fg=colour)

    def _check_nmap_on_start(self):
        """Check nmap availability and wire up live preview traces."""
        if check_nmap():
            self._nmap_badge.config(text="nmap found", bg=GREEN, fg="white")
        else:
            self._nmap_badge.config(text="nmap not found!", bg=RED, fg="white")
            messagebox.showerror(
                "Nmap Not Found",
                "Nmap is not installed or not found in your system PATH. Please install nmap to use this application.\n\n"
                "Install it from https://nmap.org/download.html",
            )
            self._run_btn.config(state="disabled")

        # Keep command preview in sync as user types
        self._target_var.trace_add("write", self._update_cmd_preview)
        self._ports_var.trace_add("write",  self._update_cmd_preview)
        self._scan_var.trace_add("write",   self._update_cmd_preview)
        self._update_cmd_preview()


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app = NmapScannerApp()
    app.mainloop()