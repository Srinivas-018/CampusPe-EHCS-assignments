import subprocess
import platform
import re
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

def ping_host(host):
    """
    Pings a host and returns a tuple (is_reachable, avg_time).
    """
    # Determine the OS to set the correct ping flags
    param = '-n' if platform.system().lower() == 'windows' else '-c'
    command = ['ping', param, '1', host]

    try:
        # Execute the ping command
        output = subprocess.check_output(command, stderr=subprocess.STDOUT, timeout=5).decode('utf-8')
        
        # Determine reachability
        is_reachable = True
        
        # Regex to extract average time (handles "Average = Xms" or "avg = X/Y/Z/W ms")
        # Matches both Windows (Average =) and Unix (avg =)
        time_match = re.search(r'(?:Average|avg).*?=\s*([\d.]+)', output, re.IGNORECASE)
        avg_time = f"{time_match.group(1)}ms" if time_match else "N/A"
        
        return is_reachable, avg_time

    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return False, "N/A"


class PingScannerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Cross-Platform Ping Scanner")
        self.geometry("760x520")
        self.minsize(640, 420)

        self.results = []
        self._build_ui()

    def _build_ui(self):
        top = tk.Frame(self, padx=12, pady=10)
        top.pack(fill="x")

        tk.Label(top, text="Cross-Platform Ping Scanner", font=("Segoe UI", 14, "bold")).pack(anchor="w")
        tk.Label(top, text="Enter hostnames/IPs separated by commas, then click Scan.", fg="#555").pack(anchor="w", pady=(2, 8))

        input_row = tk.Frame(top)
        input_row.pack(fill="x")

        tk.Label(input_row, text="Hosts:").pack(side="left", padx=(0, 6))
        self.hosts_var = tk.StringVar()
        self.hosts_entry = tk.Entry(input_row, textvariable=self.hosts_var)
        self.hosts_entry.pack(side="left", fill="x", expand=True)

        btn_row = tk.Frame(top)
        btn_row.pack(fill="x", pady=(8, 0))
        self.scan_btn = tk.Button(btn_row, text="Scan", command=self.scan_hosts)
        self.scan_btn.pack(side="left")
        tk.Button(btn_row, text="Save Results", command=self.save_results).pack(side="left", padx=8)
        tk.Button(btn_row, text="Clear", command=self.clear_results).pack(side="left")

        self.status_var = tk.StringVar(value="Ready")
        tk.Label(top, textvariable=self.status_var, fg="#0a58ca").pack(anchor="w", pady=(8, 0))

        table_frame = tk.Frame(self, padx=12, pady=8)
        table_frame.pack(fill="both", expand=True)

        self.tree = ttk.Treeview(table_frame, columns=("host", "status", "avg"), show="headings")
        self.tree.heading("host", text="Host")
        self.tree.heading("status", text="Status")
        self.tree.heading("avg", text="Avg Response")

        self.tree.column("host", width=320, anchor="w")
        self.tree.column("status", width=140, anchor="center")
        self.tree.column("avg", width=180, anchor="center")

        yscroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=yscroll.set)

        self.tree.pack(side="left", fill="both", expand=True)
        yscroll.pack(side="right", fill="y")

        bottom = tk.Frame(self, padx=12, pady=8)
        bottom.pack(fill="x")
        self.total_var = tk.StringVar(value="Total Hosts Scanned: 0")
        tk.Label(bottom, textvariable=self.total_var, font=("Segoe UI", 10, "bold")).pack(anchor="w")

    def scan_hosts(self):
        user_input = self.hosts_var.get().strip()
        if not user_input:
            messagebox.showwarning("Missing Input", "Please enter at least one hostname or IP.")
            return

        hosts = [host.strip() for host in user_input.split(',') if host.strip()]
        if not hosts:
            messagebox.showwarning("Missing Input", "Please enter valid hostname/IP values.")
            return

        self.scan_btn.config(state="disabled")
        self.status_var.set("Scanning hosts...")
        self.update_idletasks()

        self.results = []
        for host in hosts:
            reachable, avg_time = ping_host(host)
            status = "REACHABLE" if reachable else "UNREACHABLE"
            self.results.append({"host": host, "status": status, "avg": avg_time})

        self._refresh_table()
        self.total_var.set(f"Total Hosts Scanned: {len(self.results)}")
        self.status_var.set("Scan complete")
        self.scan_btn.config(state="normal")

    def _refresh_table(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        for item in self.results:
            self.tree.insert("", "end", values=(item["host"], item["status"], item["avg"]))

    def clear_results(self):
        self.results = []
        self._refresh_table()
        self.total_var.set("Total Hosts Scanned: 0")
        self.status_var.set("Cleared")

    def save_results(self):
        if not self.results:
            messagebox.showinfo("No Data", "No results to save. Please run a scan first.")
            return

        path = filedialog.asksaveasfilename(
            title="Save Ping Results",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            initialfile="ping_results.txt",
        )
        if not path:
            return

        with open(path, "w") as f:
            f.write(f"{'Host':<30} | {'Status':<12} | {'Avg Response'}\n")
            f.write("-" * 62 + "\n")
            for item in self.results:
                f.write(f"{item['host']:<30} | {item['status']:<12} | {item['avg']}\n")

        self.status_var.set(f"Saved: {path}")
        messagebox.showinfo("Saved", f"Results saved to:\n{path}")

def main():
    app = PingScannerApp()
    app.mainloop()

if __name__ == "__main__":
    main()