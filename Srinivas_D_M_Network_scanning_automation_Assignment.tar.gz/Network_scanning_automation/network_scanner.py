import platform
import re
import subprocess
import threading
import tkinter as tk
from datetime import datetime
from tkinter import filedialog, messagebox, scrolledtext, ttk


# -------------------- Shared scan logic --------------------

def ping_host(host):
    param = '-n' if platform.system().lower() == 'windows' else '-c'
    command = ['ping', param, '1', host]

    try:
        output = subprocess.check_output(
            command,
            stderr=subprocess.STDOUT,
            timeout=5,
        ).decode('utf-8', errors='ignore')

        time_match = re.search(r'(?:Average|avg).*?=\s*([\d.]+)', output, re.IGNORECASE)
        avg_time = f"{time_match.group(1)}ms" if time_match else "N/A"
        return True, avg_time
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return False, "N/A"


def get_arp_table():
    try:
        return subprocess.check_output(['arp', '-a']).decode('utf-8', errors='ignore')
    except Exception as exc:
        return f"Error retrieving ARP table: {exc}"


def parse_arp(raw_output):
    ip_pattern = r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
    mac_pattern = r'([0-9a-fA-F]{2}[:-][0-9a-fA-F]{2}[:-][0-9a-fA-F]{2}[:-][0-9a-fA-F]{2}[:-][0-9a-fA-F]{2}[:-][0-9a-fA-F]{2})'

    mappings = []
    for line in raw_output.splitlines():
        ip_match = re.search(ip_pattern, line)
        mac_match = re.search(mac_pattern, line)
        if ip_match and mac_match:
            mappings.append({
                'ip': ip_match.group(1),
                'mac': mac_match.group(1).replace('-', ':').lower(),
            })
    return mappings


def check_nmap():
    try:
        subprocess.run(['nmap', '--version'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return True
    except FileNotFoundError:
        return False


def build_nmap_command(target, scan_type, custom_ports=None):
    command = ['nmap']
    if scan_type == '1':
        command.append('-sn')
    elif scan_type == '2':
        command.extend(['-p', '1-1000'])
    elif scan_type == '3' and custom_ports:
        command.extend(['-p', custom_ports])
    elif scan_type == '4':
        command.append('-sV')
    elif scan_type == '5':
        command.append('-O')
    command.append(target)
    return command


def run_nmap_scan(target, scan_type, custom_ports=None):
    command = build_nmap_command(target, scan_type, custom_ports)
    command_text = ' '.join(command)

    try:
        result = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=300,
        )
        output = result.stdout if result.returncode == 0 else f"Error:\n{result.stderr}"
    except subprocess.TimeoutExpired:
        output = "Error: The scan timed out (5-minute limit reached)."
    except Exception as exc:
        output = f"Unexpected error: {exc}"

    return command_text, output


# -------------------- GUI app --------------------

class NetworkScannerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Network Scanner Toolkit')
        self.geometry('960x680')
        self.minsize(800, 540)

        self.ping_results = []
        self.arp_results = []
        self.nmap_thread = None

        self._build_ui()

    def _build_ui(self):
        header = tk.Frame(self, padx=12, pady=10)
        header.pack(fill='x')
        tk.Label(header, text='Network Scanner Toolkit', font=('Segoe UI', 15, 'bold')).pack(anchor='w')
        tk.Label(header, text='Integrated Ping, ARP, and Nmap scanner', fg='#555').pack(anchor='w')

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill='both', expand=True, padx=12, pady=(0, 10))

        self._build_ping_tab()
        self._build_arp_tab()
        self._build_nmap_tab()

    # -------------------- Ping tab --------------------

    def _build_ping_tab(self):
        tab = tk.Frame(self.notebook)
        self.notebook.add(tab, text='Ping Scanner')

        top = tk.Frame(tab, padx=10, pady=10)
        top.pack(fill='x')

        tk.Label(top, text='Hosts (comma-separated):').pack(side='left')
        self.ping_hosts_var = tk.StringVar()
        tk.Entry(top, textvariable=self.ping_hosts_var).pack(side='left', fill='x', expand=True, padx=(8, 8))

        self.ping_scan_btn = tk.Button(top, text='Scan', command=self.scan_ping_hosts)
        self.ping_scan_btn.pack(side='left')
        tk.Button(top, text='Save', command=self.save_ping_results).pack(side='left', padx=(8, 0))
        tk.Button(top, text='Clear', command=self.clear_ping_results).pack(side='left', padx=(8, 0))

        self.ping_status_var = tk.StringVar(value='Ready')
        tk.Label(tab, textvariable=self.ping_status_var, fg='#0a58ca', anchor='w').pack(fill='x', padx=10)

        table_frame = tk.Frame(tab, padx=10, pady=8)
        table_frame.pack(fill='both', expand=True)

        self.ping_tree = ttk.Treeview(table_frame, columns=('host', 'status', 'avg'), show='headings')
        self.ping_tree.heading('host', text='Host')
        self.ping_tree.heading('status', text='Status')
        self.ping_tree.heading('avg', text='Avg Response')
        self.ping_tree.column('host', width=350, anchor='w')
        self.ping_tree.column('status', width=160, anchor='center')
        self.ping_tree.column('avg', width=180, anchor='center')

        ping_scroll = ttk.Scrollbar(table_frame, orient='vertical', command=self.ping_tree.yview)
        self.ping_tree.configure(yscrollcommand=ping_scroll.set)
        self.ping_tree.pack(side='left', fill='both', expand=True)
        ping_scroll.pack(side='right', fill='y')

        self.ping_total_var = tk.StringVar(value='Total Hosts Scanned: 0')
        tk.Label(tab, textvariable=self.ping_total_var, font=('Segoe UI', 10, 'bold')).pack(anchor='w', padx=10, pady=(0, 10))

    def scan_ping_hosts(self):
        user_input = self.ping_hosts_var.get().strip()
        if not user_input:
            messagebox.showwarning('Missing Input', 'Please enter at least one hostname or IP.')
            return

        hosts = [host.strip() for host in user_input.split(',') if host.strip()]
        if not hosts:
            messagebox.showwarning('Missing Input', 'Please enter valid hostname/IP values.')
            return

        self.ping_scan_btn.config(state='disabled')
        self.ping_status_var.set('Scanning hosts...')
        self.update_idletasks()

        self.ping_results = []
        for host in hosts:
            reachable, avg_time = ping_host(host)
            status = 'REACHABLE' if reachable else 'UNREACHABLE'
            self.ping_results.append({'host': host, 'status': status, 'avg': avg_time})

        self._refresh_ping_table()
        self.ping_total_var.set(f"Total Hosts Scanned: {len(self.ping_results)}")
        self.ping_status_var.set('Scan complete')
        self.ping_scan_btn.config(state='normal')

    def _refresh_ping_table(self):
        for row in self.ping_tree.get_children():
            self.ping_tree.delete(row)
        for item in self.ping_results:
            self.ping_tree.insert('', 'end', values=(item['host'], item['status'], item['avg']))

    def clear_ping_results(self):
        self.ping_results = []
        self._refresh_ping_table()
        self.ping_total_var.set('Total Hosts Scanned: 0')
        self.ping_status_var.set('Cleared')

    def save_ping_results(self):
        if not self.ping_results:
            messagebox.showinfo('No Data', 'No ping results to save. Please run a scan first.')
            return

        path = filedialog.asksaveasfilename(
            title='Save Ping Results',
            defaultextension='.txt',
            filetypes=[('Text files', '*.txt'), ('All files', '*.*')],
            initialfile='ping_results.txt',
        )
        if not path:
            return

        with open(path, 'w') as file:
            file.write(f"{'Host':<30} | {'Status':<12} | {'Avg Response'}\n")
            file.write('-' * 62 + '\n')
            for item in self.ping_results:
                file.write(f"{item['host']:<30} | {item['status']:<12} | {item['avg']}\n")

        self.ping_status_var.set(f'Saved: {path}')
        messagebox.showinfo('Saved', f'Results saved to:\n{path}')

    # -------------------- ARP tab --------------------

    def _build_arp_tab(self):
        tab = tk.Frame(self.notebook)
        self.notebook.add(tab, text='ARP Scanner')

        top = tk.Frame(tab, padx=10, pady=10)
        top.pack(fill='x')

        self.arp_scan_btn = tk.Button(top, text='Scan ARP Table', command=self.scan_arp)
        self.arp_scan_btn.pack(side='left')
        tk.Button(top, text='Save', command=self.save_arp_results).pack(side='left', padx=(8, 0))
        tk.Button(top, text='Clear', command=self.clear_arp_results).pack(side='left', padx=(8, 0))

        self.arp_status_var = tk.StringVar(value='Ready')
        tk.Label(tab, textvariable=self.arp_status_var, fg='#0a58ca', anchor='w').pack(fill='x', padx=10)

        table_frame = tk.Frame(tab, padx=10, pady=8)
        table_frame.pack(fill='both', expand=True)

        self.arp_tree = ttk.Treeview(table_frame, columns=('ip', 'mac'), show='headings')
        self.arp_tree.heading('ip', text='IP Address')
        self.arp_tree.heading('mac', text='MAC Address')
        self.arp_tree.column('ip', width=280, anchor='w')
        self.arp_tree.column('mac', width=320, anchor='w')

        arp_scroll = ttk.Scrollbar(table_frame, orient='vertical', command=self.arp_tree.yview)
        self.arp_tree.configure(yscrollcommand=arp_scroll.set)
        self.arp_tree.pack(side='left', fill='both', expand=True)
        arp_scroll.pack(side='right', fill='y')

        self.arp_total_var = tk.StringVar(value='Total Entries Found: 0')
        tk.Label(tab, textvariable=self.arp_total_var, font=('Segoe UI', 10, 'bold')).pack(anchor='w', padx=10, pady=(0, 10))

    def scan_arp(self):
        self.arp_status_var.set('Scanning ARP table...')
        self.update_idletasks()

        raw_data = get_arp_table()
        if raw_data.startswith('Error retrieving ARP table:'):
            self.arp_status_var.set('Scan failed')
            messagebox.showerror('ARP Scan Error', raw_data)
            return

        self.arp_results = parse_arp(raw_data)
        self._refresh_arp_table()
        self.arp_total_var.set(f'Total Entries Found: {len(self.arp_results)}')
        self.arp_status_var.set('Scan complete')

    def _refresh_arp_table(self):
        for row in self.arp_tree.get_children():
            self.arp_tree.delete(row)
        for entry in self.arp_results:
            self.arp_tree.insert('', 'end', values=(entry['ip'], entry['mac']))

    def clear_arp_results(self):
        self.arp_results = []
        self._refresh_arp_table()
        self.arp_total_var.set('Total Entries Found: 0')
        self.arp_status_var.set('Cleared')

    def save_arp_results(self):
        if not self.arp_results:
            messagebox.showinfo('No Data', 'No ARP entries to save. Please scan first.')
            return

        path = filedialog.asksaveasfilename(
            title='Save ARP Results',
            defaultextension='.txt',
            filetypes=[('Text files', '*.txt'), ('All files', '*.*')],
            initialfile='arp_results.txt',
        )
        if not path:
            return

        with open(path, 'w') as file:
            file.write(f"Total ARP Entries Found: {len(self.arp_results)}\n")
            file.write('-' * 40 + '\n')
            file.write(f"{'IP Address':<20} | {'MAC Address'}\n")
            for entry in self.arp_results:
                file.write(f"{entry['ip']:<20} | {entry['mac']}\n")

        self.arp_status_var.set(f'Saved: {path}')
        messagebox.showinfo('Saved', f'Results saved to:\n{path}')

    # -------------------- Nmap tab --------------------

    def _build_nmap_tab(self):
        tab = tk.Frame(self.notebook)
        self.notebook.add(tab, text='Nmap Scanner')

        container = tk.Frame(tab, padx=10, pady=10)
        container.pack(fill='both', expand=True)

        left = tk.Frame(container)
        left.pack(side='left', fill='y', padx=(0, 10))

        right = tk.Frame(container)
        right.pack(side='left', fill='both', expand=True)

        tk.Label(left, text='Target').pack(anchor='w')
        self.nmap_target_var = tk.StringVar()
        tk.Entry(left, textvariable=self.nmap_target_var, width=32).pack(anchor='w', pady=(2, 6))

        tk.Label(left, text='Scan Type').pack(anchor='w')
        self.nmap_scan_var = tk.StringVar(value='1')
        options = [
            ('1', 'Host Discovery (-sn)'),
            ('2', 'Port Scan 1-1000 (-p 1-1000)'),
            ('3', 'Custom Port Range (-p)'),
            ('4', 'Service Version (-sV)'),
            ('5', 'OS Detection (-O)'),
        ]
        for value, text in options:
            tk.Radiobutton(left, text=text, value=value, variable=self.nmap_scan_var,
                           command=self._on_nmap_scan_type_change).pack(anchor='w')

        tk.Label(left, text='Custom ports').pack(anchor='w', pady=(8, 0))
        self.nmap_ports_var = tk.StringVar()
        self.nmap_ports_entry = tk.Entry(left, textvariable=self.nmap_ports_var, state='disabled')
        self.nmap_ports_entry.pack(anchor='w', fill='x', pady=(2, 8))

        self.nmap_run_btn = tk.Button(left, text='Run Scan', command=self.start_nmap_scan)
        self.nmap_run_btn.pack(fill='x')
        tk.Button(left, text='Save', command=self.save_nmap_output).pack(fill='x', pady=(6, 0))
        tk.Button(left, text='Clear', command=self.clear_nmap_output).pack(fill='x', pady=(6, 0))

        self.nmap_check_var = tk.StringVar()
        tk.Label(left, textvariable=self.nmap_check_var, fg='#0a58ca').pack(anchor='w', pady=(8, 0))

        self.nmap_cmd_var = tk.StringVar(value='Command: -')
        tk.Label(right, textvariable=self.nmap_cmd_var, anchor='w', fg='#5e35b1').pack(fill='x')

        self.nmap_output = scrolledtext.ScrolledText(right, wrap='word', state='disabled')
        self.nmap_output.pack(fill='both', expand=True, pady=(4, 0))

        self.nmap_status_var = tk.StringVar(value='Ready')
        tk.Label(tab, textvariable=self.nmap_status_var, fg='#0a58ca', anchor='w').pack(fill='x', padx=10, pady=(0, 8))

        self._check_nmap_availability()

    def _check_nmap_availability(self):
        if check_nmap():
            self.nmap_check_var.set('nmap found')
            self.nmap_run_btn.config(state='normal')
        else:
            self.nmap_check_var.set('nmap not found in PATH')
            self.nmap_run_btn.config(state='disabled')

    def _on_nmap_scan_type_change(self):
        if self.nmap_scan_var.get() == '3':
            self.nmap_ports_entry.config(state='normal')
        else:
            self.nmap_ports_entry.config(state='disabled')
        self._update_nmap_command_preview()

    def _update_nmap_command_preview(self):
        target = self.nmap_target_var.get().strip() or '<target>'
        ports = self.nmap_ports_var.get().strip() or None
        command = build_nmap_command(target, self.nmap_scan_var.get(), ports)
        self.nmap_cmd_var.set('Command: ' + ' '.join(command))

    def start_nmap_scan(self):
        target = self.nmap_target_var.get().strip()
        if not target:
            messagebox.showwarning('No Target', 'Please enter a target IP/hostname/network range.')
            return
        if self.nmap_scan_var.get() == '3' and not self.nmap_ports_var.get().strip():
            messagebox.showwarning('No Ports', 'Please enter a custom port range for this scan type.')
            return
        if self.nmap_thread and self.nmap_thread.is_alive():
            messagebox.showinfo('Busy', 'An nmap scan is already running.')
            return

        self.nmap_run_btn.config(state='disabled', text='Scanning...')
        self.nmap_status_var.set('Scanning... please wait')
        self.clear_nmap_output()

        self.nmap_thread = threading.Thread(
            target=self._nmap_worker,
            args=(target, self.nmap_scan_var.get(), self.nmap_ports_var.get().strip() or None),
            daemon=True,
        )
        self.nmap_thread.start()

    def _nmap_worker(self, target, scan_type, ports):
        command_text, output = run_nmap_scan(target, scan_type, ports)
        self.after(0, self._display_nmap_result, command_text, output)

    def _display_nmap_result(self, command_text, output):
        self.nmap_cmd_var.set('Command: ' + command_text)

        stamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        content = f"Scan completed: {stamp}\n{'-' * 70}\n{output}\n"

        self.nmap_output.config(state='normal')
        self.nmap_output.insert('end', content)
        self.nmap_output.config(state='disabled')
        self.nmap_output.see('end')

        has_error = output.lower().startswith('error') or output.lower().startswith('unexpected')
        self.nmap_status_var.set('Scan finished with errors' if has_error else 'Scan complete')
        self.nmap_run_btn.config(state='normal', text='Run Scan')

    def clear_nmap_output(self):
        self.nmap_output.config(state='normal')
        self.nmap_output.delete('1.0', 'end')
        self.nmap_output.config(state='disabled')
        self.nmap_status_var.set('Ready')

    def save_nmap_output(self):
        content = self.nmap_output.get('1.0', 'end').strip()
        if not content:
            messagebox.showinfo('No Data', 'No nmap output to save. Please run a scan first.')
            return

        path = filedialog.asksaveasfilename(
            title='Save Nmap Output',
            defaultextension='.txt',
            filetypes=[('Text files', '*.txt'), ('All files', '*.*')],
            initialfile='nmap_report.txt',
        )
        if not path:
            return

        with open(path, 'w') as file:
            file.write(content)

        self.nmap_status_var.set(f'Saved: {path}')
        messagebox.showinfo('Saved', f'Results saved to:\n{path}')


def main():
    app = NetworkScannerApp()
    app.mainloop()


if __name__ == '__main__':
    main()
