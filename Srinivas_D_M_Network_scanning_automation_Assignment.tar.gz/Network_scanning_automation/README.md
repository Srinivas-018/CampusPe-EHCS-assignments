# Network Scanning Automation Toolkit

## Quick Start (60 seconds)
```bash
cd Network_scanning_automation
sudo apt update && sudo apt install -y python3 python3-tk nmap iputils-ping net-tools
python3 network_scanner.py
```

If your system uses `python` instead of `python3`, replace the command accordingly.

## Project Description
This folder contains Python-based network scanning tools with Tkinter GUIs:

- `ping_scanner.py` – scan one or more hosts and check reachability/average response time.
- `arp_scanner.py` – read and display local ARP cache entries (IP ↔ MAC mapping).
- `nmap_scanner.py` – run different Nmap scan types from a desktop GUI.
- `network_scanner.py` – all-in-one toolkit that combines Ping, ARP, and Nmap scanners in tabs.

These tools are intended for learning and authorized network diagnostics only.

## Prerequisites
- Python 3.8+
- `tkinter` (usually included with standard Python desktop installs)
- `ping` and `arp` commands available in your system
- **Nmap** installed (required for `nmap_scanner.py` and Nmap tab in `network_scanner.py`)

---

## How to Install Nmap

### Ubuntu / Debian
```bash
sudo apt update
sudo apt install nmap -y
```

### Fedora
```bash
sudo dnf install nmap -y
```

### Arch Linux
```bash
sudo pacman -S nmap
```

### macOS (Homebrew)
```bash
brew install nmap
```

### Windows
- Download installer from: https://nmap.org/download.html
- Install Nmap and ensure it is added to your `PATH`.

### Verify Installation
```bash
nmap --version
```

---

## How to Run Each Program
From inside this folder (`Network_scanning_automation`):

```bash
python3 ping_scanner.py
python3 arp_scanner.py
python3 nmap_scanner.py
python3 network_scanner.py
```

If your system uses `python` instead of `python3`, replace accordingly.

---

## Example Usage for Each Tool

### 1) Ping Scanner (`ping_scanner.py`)
1. Enter hosts in the input box, comma-separated.
2. Click **Scan**.
3. View table output: Host, Status (`REACHABLE`/`UNREACHABLE`), Avg Response.
4. Optionally click **Save Results**.

**Example input:**
```
8.8.8.8, 1.1.1.1, google.com
```

---

### 2) ARP Scanner (`arp_scanner.py`)
1. Click **Scan ARP Table**.
2. The app parses local ARP cache and shows IP + MAC entries.
3. Review total entry count.
4. Optionally click **Save Results**.

**Example output row:**
```
192.168.1.10 | aa:bb:cc:dd:ee:ff
```

---

### 3) Nmap Scanner (`nmap_scanner.py`)
1. Enter target (single host or subnet).
2. Select scan type:
   - Host Discovery (`-sn`)
   - Port Scan `1-1000`
   - Custom Port Range (`-p`)
   - Service Version (`-sV`)
   - OS Detection (`-O`)
3. For Custom Port Range, enter ports (e.g., `22,80,443` or `1-1024`).
4. Click **Run Scan** and view results.
5. Optionally click **Save Results**.

**Example target:**
```
192.168.1.0/24
```

---

### 4) Integrated Toolkit (`network_scanner.py`)
1. Launch app and use tabs:
   - **Ping Scanner** tab for host reachability
   - **ARP Scanner** tab for local ARP entries
   - **Nmap Scanner** tab for advanced scans
2. Run scans from each tab as needed.
3. Save outputs from each tab separately.

**Example workflow:**
1. Ping `192.168.1.1, 8.8.8.8`
2. Check ARP table for discovered devices
3. Run Nmap Service Version scan (`-sV`) on one responsive host

---

## Notes
- Some scans may require elevated privileges depending on OS and selected scan type.
- Only scan networks and hosts you own or have explicit permission to test.

---

## Troubleshooting

### `python3: command not found`
- Try using:
```bash
python ping_scanner.py
```
- Or install Python 3:
```bash
sudo apt install python3 -y
```

### `ModuleNotFoundError: No module named tkinter`
- Install Tkinter package:
```bash
sudo apt install python3-tk -y
```

### `nmap not found in PATH`
- Install Nmap using the steps above.
- Verify:
```bash
nmap --version
```

### Permission / privileged scan issues
- Some Nmap features (for example OS detection `-O`) may require root privileges on Linux.
- Run with sudo if needed:
```bash
sudo python3 nmap_scanner.py
```

### `arp` or `ping` command not found
- Install networking tools package (Linux example):
```bash
sudo apt install iputils-ping net-tools -y
```

### Scan returns no hosts
- Check that target IP/range is correct.
- Make sure your machine is connected to the expected network.
- Temporarily check local firewall/security rules that may block probes.
